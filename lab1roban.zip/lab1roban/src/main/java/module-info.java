module com.example.lab1roban {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens com.example.lab1roban to javafx.fxml;
    exports com.example.lab1roban;
}