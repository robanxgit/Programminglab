package com.example.lab1roban;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import java.net.URL;
import java.util.ResourceBundle;
import java.sql.*;
public class HelloController implements Initializable {
    @FXML
    private TableView<Appointment> tableView;
    @FXML
    private TableColumn<Appointment,Integer > EID;
    @FXML
    private TableColumn<Appointment, String> Name;
    @FXML
    private TableColumn<Appointment,String> Email;
    @FXML
    private TableColumn<Appointment,Integer> Phone;
    ObservableList<Appointment> list = FXCollections.observableArrayList();
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        EID.setCellValueFactory(new
                PropertyValueFactory<Appointment,Integer>("EID"));
        Name.setCellValueFactory(new
                PropertyValueFactory<Appointment,String>("Name"));
        Email.setCellValueFactory(new
                PropertyValueFactory<Appointment,String>("Email"));
        Phone.setCellValueFactory(new
                PropertyValueFactory<Appointment,Integer>("Phone"));
        tableView.setItems(list);
    }
    @FXML
    protected void onHelloButtonClick() {
        populateTable();
    }
    public void populateTable() {
        // Establish a database connection
        String jdbcUrl = "jdbc:mysql://localhost:3306/lab1roban";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser,
                dbPassword)) {
            // Execute a SQL query to retrieve data from the database
            String query = "SELECT * FROM employees";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);
            // Populate the table with data from the database
            while (resultSet.next()) {
                int EID = resultSet.getInt("EID");
                String Name = resultSet.getString("Name");
                String Email = resultSet.getString("Emial");
                int Phone = resultSet.getInt("Phone");
                tableView.getItems().add(new Appointment(EID, Name, Email,
                        Phone));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
